package com.example.flutter_application_uts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
